# redBus-Clone

## Project Overview
A Front Page Clone of redBus.

### How to run this Application?
  * Download as .zip file or clone this project:
    ```
    $ git clone https://github.com/msgaurav/redBus-Clone
    ```
    * If downloaded, unzip and open **main.html** file in a browser.
  - Or you can directly [Click here:point_up_2:](https://codepen.io/msgaurav/full/XQjPbE) to run this application.

### Skills Used
  * HTML5
  * CSS3
  * Bootstrap 4
  * JavaScript
  * jQuery
  
#### Note
  * I do not own any copyrights, all the rights go to their respective owners. Thank You.:smiley:
